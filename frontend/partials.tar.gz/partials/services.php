<?php include('top.php') ?>

<div class="container-fluid event_top_block">
  <div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
<div class="event_bannersloderbox">


<div class="event_bannerbg"><img src="images/services_topbanner.png" alt="#"></div>

<div class="bannerbgred"><img src="images/redbg.png" alt="#"></div>
<div class="logo">
 <a href="javascript:void(0)"><img src="images/logo.png" alt="#" ></a>
 </div>

<img src="images/servicesheading.png" alt="#" class="contact_bannertext">

    <img src="images/servicesdrone.png" alt="#" class="event_bannerdrone">

</div>

</div>
</div>
</div>

 <div class="clear"></div>
 
 
 <div class="container-fluid contact_body_container">
 
   <div class="row">
   
   <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 services_wrapper ">
  
  
 <div class="services_blog">
  <div class="services_heading"><div><label><h3>SPECIALIZED<span>/MEDIA</span></h3></label></div></div>
  
  <img src="images/sevicesimg1.png" alt="#" class="servicesimg" />
  
  <div class="services_textwrapper">
  <p>Our pilots are constantly flying and filming and building our library of stock photos and video. Beautiful sweeping landscapes, scenes of mayan ruins, gorgeous beaches, city skylines and more. our stock media makes an excellent addition to promotional and commercial videos and more.</p>
  
     <a href="javascript:void(0)" class="viewbtn"> View more </a>
  
  </div>
 
 
 </div>

<div class="services_blog">
  <div class="services_heading"><div><label><h3>TRAINING</h3></label></div></div>
  
  <img src="images/sevicesimg2.png" alt="#" class="servicesimg" />
  
  <div class="services_textwrapper">
  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus nulla nibh, efficitur ac risus a, pharetra bibendum nulla. Nulla interdum sem at malesuada tincidunt. Phasellus at orci odio. Curabitur commodo tincidunt mi at porta. Aenean mattis turpis pellentesque metus scelerisque interdum.</p>  <a href="javascript:void(0)" class="viewbtn"> View more </a>
  
  </div>
 
 
 </div>
 
 
 <div class="services_blog">
  <div class="services_heading"><div><label><h3>Repair</h3></label></div></div>
  
  <img src="images/sevicesimg3.png" alt="#" class="servicesimg" />
  
  <div class="services_textwrapper">
  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus nulla nibh, efficitur ac risus a, pharetra bibendum nulla. Nulla interdum sem at malesuada tincidunt. Phasellus at orci odio. Curabitur commodo tincidunt mi at porta. Aenean mattis turpis pellentesque metus scelerisque interdum.</p>  <a href="javascript:void(0)" class="viewbtn"> View more </a>
  
  </div>
 
 
 </div>
   
   <div class="services_blog">
  <div class="services_heading"><div><label><h3>Package <span>Delivery</span></h3></label></div></div>
  
  <img src="images/sevicesimg4.png" alt="#" class="servicesimg" />
  
  <div class="services_textwrapper">
  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus nulla nibh, efficitur ac risus a, pharetra bibendum nulla. Nulla interdum sem at malesuada tincidunt. Phasellus at orci odio. Curabitur commodo tincidunt mi at porta. Aenean mattis turpis pellentesque metus scelerisque interdum.</p>  <a href="javascript:void(0)" class="viewbtn"> View more </a>
  
  </div>
 
 
 </div>
   
   
   <div class="services_blog">
  <div class="services_heading"><div><label><h3>Package <span>Delivery</span></h3></label></div></div>
  
  <img src="images/sevicesimg4.png" alt="#" class="servicesimg" />
  
  <div class="services_textwrapper">
  <p>There are times when you may need delivery of small packages to areas that are difficult to get to using conventional transportation. In these cases drones are perfect for getting the job done. Our pilots will deliver your package quickly and safely despite heavy traffic or remote location.<br />
<br />


With the convenience this delivery system makes available it's no surprise that Fortune 500 companies like Amazon and many others are already beginning to use drones for deliveries.</p>  <a href="javascript:void(0)" class="viewbtn"> View more </a>
  
  </div>
 
 
 </div>
 
 <div class="services_blog">
  <div class="services_heading"><div><label><h3>AERIAL <span>Videography/Photography</span></h3></label></div></div>
  
  <img src="images/sevicesimg5.png" alt="#" class="servicesimg" />
  
  <div class="services_textwrapper">
  <p>Jungle Drones brings the global FPV racing community exciting, professionally organized, highly competitive racing competitions. Jungle Drones' partnerships provide sponsors the opportunity to present their flagship products, innovations and branding to their most avid fans in a hands-on, real world competitive environment.
<br />
<br />

Jungle Drones leverages its rapidly growing social media reach to engage enthusiasts and activate newcomers. From groundbreaking drone technology, race course design and advancing safety standards, Jungle Drones welcomes innovation and seeks to raise public awareness of this sport.<br />
<br />


Join our Drone Racing community today and we will keep you informed of upcoming races, locations and prizes as well as the latest news for the drone racing world.
</p>  <a href="javascript:void(0)" class="viewbtn"> View more </a>
  
  </div>
 
 
 </div>
   

      </div>
   
 
  </div>
 </div>
 
 
<?php include('footer.php') ?>
