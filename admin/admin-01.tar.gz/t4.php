<?php
/**
 * Created by PhpStorm.
 * User: iftekar
 * Date: 22/4/16
 * Time: 4:48 PM
 */

;
phpinfo();

?>